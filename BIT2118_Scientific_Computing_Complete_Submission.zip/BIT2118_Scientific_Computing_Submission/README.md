# BIT 2118 Scientific Computing – Individual Practical Work

This repository contains implementations for all practical tasks 2–20 in the assignment brief.

## Structure
- `BIT2118_Complete_Report.docx` – report with inputs, mathematical operations, parameter changes and interpretations.
- `code/` – one runnable Python script per task.

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install numpy scipy matplotlib
```

## Run
```powershell
python code/Task_02_numpy_arrays.py
```
Run each file separately. Tasks involving Matplotlib open a graph window.

## Important
- The data are illustrative/simulated and should not be represented as actual field measurements.
- Run the scripts on your computer and record the actual output. Execution times vary by hardware.
- Add your name, registration number, group and personal GitHub URL to the report.
- This must be uploaded to your own individual GitHub repository, not a shared group repository.
