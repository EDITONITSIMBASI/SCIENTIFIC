import numpy as np
from scipy.optimize import minimize

# Related case: minimize cost of two types of water-storage capacity.
# A costs 10 units and supplies 80 capacity; B costs 16 and supplies 150.
def cost(z):
    a, b = z
    return 10*a + 16*b
def capacity(z):
    a, b = z
    return 80*a + 150*b - 900
result = minimize(cost, x0=[5, 4], method="SLSQP",
                  bounds=[(0, None), (0, None)],
                  constraints={"type": "ineq", "fun": capacity})
a, b = result.x
print("Optimization success:", result.success)
print(f"Continuous A allocation: {a:.3f}")
print(f"Continuous B allocation: {b:.3f}")
print(f"Capacity achieved: {80*a+150*b:.2f}")
print(f"Minimum continuous cost: {result.fun:.2f}")
# Integer search because actual tanks/units may need to be whole numbers.
candidates = [(10*i+16*j, i, j, 80*i+150*j)
              for i in range(20) for j in range(20) if 80*i+150*j >= 900]
print("Best integer plan (cost, A, B, capacity):", min(candidates))
