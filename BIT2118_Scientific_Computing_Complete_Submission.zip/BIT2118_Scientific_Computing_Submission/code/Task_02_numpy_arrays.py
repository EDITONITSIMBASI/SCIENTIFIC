import numpy as np

# Related case: monitor water levels from an estate reservoir (metres).
levels_m = np.array([2.1, 2.3, 2.2, 2.5, 2.7, 2.6, 2.4, 2.8])
print("Readings (m):", levels_m)
print(f"Mean level: {np.mean(levels_m):.3f} m")
print(f"Minimum level: {np.min(levels_m):.3f} m")
print(f"Maximum level: {np.max(levels_m):.3f} m")
# Change: convert the measurements to centimetres.
levels_cm = levels_m * 100
print("First four readings (cm):", levels_cm[:4])
