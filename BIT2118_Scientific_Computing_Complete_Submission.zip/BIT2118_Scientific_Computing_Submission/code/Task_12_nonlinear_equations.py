import numpy as np
from scipy.optimize import root

# Related case: find where a circular irrigation field boundary meets a parabolic drainage channel.
# Circle radius 3: x^2+y^2=9; channel: y=x^2-2.
def equations(z):
    x, y = z
    return [x**2 + y**2 - 9, y - (x**2 - 2)]
for guess in ([1., 1.], [-1., 1.], [2., 2.]):
    sol = root(equations, guess)
    print("Initial guess:", guess)
    print("Intersection (x,y):", sol.x)
    print("Residuals:", equations(sol.x))
    print("Converged:", sol.success)
