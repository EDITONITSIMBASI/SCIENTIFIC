import numpy as np
import matplotlib.pyplot as plt

# Related case: steady-state temperatures across five points in a greenhouse.
A = np.array([[4., -1., 0., 0., 0.],
              [-1., 4., -1., 0., 0.],
              [0., -1., 4., -1., 0.],
              [0., 0., -1., 4., -1.],
              [0., 0., 0., -1., 4.]])
b = np.array([80., 0., 0., 0., 40.])
def jacobi(A, b, tol=1e-7, max_iter=1000):
    D = np.diag(A); R = A - np.diagflat(D)
    x = np.zeros_like(b); errors = []
    for _ in range(max_iter):
        xn = (b - R @ x) / D
        err = np.linalg.norm(xn - x, ord=np.inf); errors.append(err)
        if err < tol: return xn, errors
        x = xn
    return x, errors
def gauss_seidel(A, b, tol=1e-7, max_iter=1000):
    x = np.zeros_like(b); errors = []
    for _ in range(max_iter):
        old = x.copy()
        for i in range(len(b)):
            x[i] = (b[i] - A[i, :i] @ x[:i] - A[i, i+1:] @ old[i+1:]) / A[i, i]
        err = np.linalg.norm(x-old, ord=np.inf); errors.append(err)
        if err < tol: return x, errors
    return x, errors
xj, ej = jacobi(A, b); xg, eg = gauss_seidel(A, b)
print("Jacobi:", xj); print("Gauss-Seidel:", xg)
print("Direct check:", np.linalg.solve(A, b))
plt.semilogy(ej, label="Jacobi"); plt.semilogy(eg, label="Gauss-Seidel")
plt.xlabel("Iteration"); plt.ylabel("Maximum change")
plt.title("Greenhouse temperature model convergence"); plt.legend(); plt.grid(True); plt.show()
