import numpy as np
import matplotlib.pyplot as plt

# Related case: cooling of a greenhouse water tank after heating.
ambient = 24.0
initial = 75.0
k = 0.08
h = 0.5  # changed from one-minute steps
end = 30.0
time = np.arange(0, end+h, h)
temp = np.zeros_like(time); temp[0] = initial
for i in range(len(time)-1):
    temp[i+1] = temp[i] + h * (-k*(temp[i]-ambient))
exact = ambient + (initial-ambient)*np.exp(-k*time)
print(f"Euler temperature after {end:.0f} min: {temp[-1]:.3f} C")
print(f"Exact temperature after {end:.0f} min: {exact[-1]:.3f} C")
print(f"Absolute error: {abs(temp[-1]-exact[-1]):.5f} C")
plt.plot(time, temp, marker=".", label="Euler")
plt.plot(time, exact, label="Exact solution")
plt.xlabel("Time (minutes)"); plt.ylabel("Temperature (C)")
plt.title("Greenhouse tank cooling"); plt.legend(); plt.grid(True); plt.show()
