import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Related case: model water demand as the number of households increases.
households = np.array([10, 20, 30, 40, 50, 60, 70], dtype=float)
demand = np.array([4.2, 7.8, 12.5, 18.1, 24.7, 32.2, 40.5])
def model(x, a, b, c):
    return a*x**2 + b*x + c
params, _ = curve_fit(model, households, demand)
pred = model(households, *params)
rmse = np.sqrt(np.mean((demand-pred)**2))
print(f"Fitted model: y={params[0]:.6f}x^2 + {params[1]:.4f}x + {params[2]:.3f}")
print(f"RMSE: {rmse:.3f} demand units")
print(f"Estimated demand for 80 households: {model(80, *params):.2f}")
x = np.linspace(10, 80, 250)
plt.scatter(households, demand, label="Observed")
plt.plot(x, model(x, *params), label="Quadratic fit")
plt.xlabel("Households"); plt.ylabel("Daily water demand (m3)")
plt.title("Household water-demand curve fitting"); plt.legend(); plt.grid(True); plt.show()
