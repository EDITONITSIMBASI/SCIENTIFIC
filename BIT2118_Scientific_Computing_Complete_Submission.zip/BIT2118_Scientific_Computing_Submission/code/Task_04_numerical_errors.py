import numpy as np

# Related case: calculate medicine-free laboratory solution concentration ratios.
# Demonstrates numerical precision only; values are illustrative measurements.
computed = 0.1 + 0.2
expected = 0.3
print("0.1 + 0.2 =", repr(computed))
print("Exact equality:", computed == expected)
print("Tolerance comparison:", np.isclose(computed, expected))

reference = np.sqrt(5)
rounded = 2.236
absolute_error = abs(reference - rounded)
relative_error = absolute_error / abs(reference)
print(f"Absolute error: {absolute_error:.8f}")
print(f"Relative error: {relative_error:.6%}")

# Compare direct and algebraically stable forms for small x.
for x in [1e-4, 1e-8, 1e-12]:
    direct = (np.sqrt(1 + x) - 1) / x
    stable = 1 / (np.sqrt(1 + x) + 1)
    print(f"x={x:.0e}: direct={direct:.10f}, stable={stable:.10f}")
# Change: use sqrt(5) rather than sqrt(2), and test three small x values.
