import numpy as np

# Related case: rotate and scale coordinates of a small solar-panel layout.
points = np.array([[0., 0.], [2., 0.], [2., 1.], [0., 1.]])
angle = np.deg2rad(30)  # changed from 45 degrees
rotation = np.array([[np.cos(angle), -np.sin(angle)],
                     [np.sin(angle),  np.cos(angle)]])
scale = np.array([[1.5, 0.], [0., 2.]])
transform = rotation @ scale
new_points = points @ transform.T
print("Original coordinates:\n", points)
print("Transformation matrix:\n", transform)
print("Transformed coordinates:\n", new_points)
print("Determinant:", np.linalg.det(transform))
