import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, CubicSpline

# Related case: estimate water-tank level between hourly sensor readings.
hours = np.array([6, 7, 8, 9, 10, 11, 12], dtype=float)
level = np.array([1.2, 1.35, 1.55, 1.70, 1.82, 1.90, 1.95])
linear = interp1d(hours, level)
cubic = CubicSpline(hours, level)
target = 8.5  # changed target time
print(f"Linear estimate at {target}: {float(linear(target)):.3f} m")
print(f"Cubic estimate at {target}: {float(cubic(target)):.3f} m")
fine = np.linspace(hours.min(), hours.max(), 200)
plt.scatter(hours, level, label="Sensor readings")
plt.plot(fine, linear(fine), label="Linear")
plt.plot(fine, cubic(fine), label="Cubic spline")
plt.xlabel("Hour"); plt.ylabel("Tank level (m)")
plt.title("Water-tank level interpolation"); plt.legend(); plt.grid(True); plt.show()
