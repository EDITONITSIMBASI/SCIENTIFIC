import numpy as np
import matplotlib.pyplot as plt

# Related case: estimate speed of a delivery vehicle from GPS position samples.
time_s = np.array([0, 1, 2, 3, 4, 5, 6], dtype=float)
position_m = np.array([0, 3.2, 7.0, 11.5, 16.8, 22.8, 29.5])
speed = np.zeros_like(position_m)
speed[0] = (position_m[1]-position_m[0])/(time_s[1]-time_s[0])
for i in range(1, len(time_s)-1):
    speed[i] = (position_m[i+1]-position_m[i-1])/(time_s[i+1]-time_s[i-1])
speed[-1] = (position_m[-1]-position_m[-2])/(time_s[-1]-time_s[-2])
for t, p, v in zip(time_s, position_m, speed):
    print(f"t={t:.0f}s position={p:.1f}m estimated speed={v:.2f}m/s")
plt.plot(time_s, speed, marker="o")
plt.xlabel("Time (s)"); plt.ylabel("Estimated speed (m/s)")
plt.title("Delivery vehicle speed from GPS data"); plt.grid(True); plt.show()
