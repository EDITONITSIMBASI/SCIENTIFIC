import numpy as np

# Related case: identify influential intersections in a small road network.
# Nodes P,Q,R,S; 1 indicates a direct connection.
network = np.array([[0., 1., 1., 0.],
                    [1., 0., 1., 1.],
                    [1., 1., 0., 1.],
                    [0., 1., 1., 0.]])
values, vectors = np.linalg.eig(network)
idx = np.argmax(np.real(values))
dominant_value = np.real(values[idx])
v = np.abs(np.real(vectors[:, idx]))
scores = v / v.sum()
print("Dominant eigenvalue:", dominant_value)
for node, score in zip(["P", "Q", "R", "S"], scores):
    print(f"Intersection {node}: importance={score:.4f}")
print("Verification error:", np.linalg.norm(network @ vectors[:, idx] - values[idx] * vectors[:, idx]))
