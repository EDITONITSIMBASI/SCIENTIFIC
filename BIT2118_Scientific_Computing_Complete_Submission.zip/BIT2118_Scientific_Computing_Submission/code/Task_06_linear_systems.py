import numpy as np

# Related case: estimate quantities of two resource packages from CPU and RAM totals.
# Package A: 3 CPU units and 6 GB RAM; Package B: 2 CPU units and 10 GB RAM.
A = np.array([[3., 2.], [6., 10.]])
b = np.array([19., 54.])  # changed resource totals
solution = np.linalg.solve(A, b)
print(f"Package A units: {solution[0]:.3f}")
print(f"Package B units: {solution[1]:.3f}")
print("Reconstructed totals:", A @ solution)
print("Residual:", b - A @ solution)
