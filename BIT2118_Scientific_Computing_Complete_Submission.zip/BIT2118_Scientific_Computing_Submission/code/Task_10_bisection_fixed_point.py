import numpy as np
from scipy.optimize import root_scalar
import matplotlib.pyplot as plt

# Related case: estimate the temperature where a greenhouse heat balance is zero.
def balance(T):
    return T - 22 - 8 * np.exp(-T / 18)  # changed constants
root = root_scalar(balance, bracket=[15, 40], method="bisect", xtol=1e-10)
def g(T):
    return 22 + 8 * np.exp(-T / 18)
T = 28.; history = [T]
for _ in range(200):
    nxt = g(T); history.append(nxt)
    if abs(nxt-T) < 1e-10: break
    T = nxt
print(f"Bisection root: {root.root:.6f} C")
print(f"Fixed-point estimate: {history[-1]:.6f} C")
print("Fixed-point iterations:", len(history)-1)
x = np.linspace(15, 40, 300)
plt.plot(x, balance(x)); plt.axhline(0); plt.axvline(root.root, linestyle="--")
plt.xlabel("Temperature (C)"); plt.ylabel("Heat balance")
plt.title("Greenhouse heat-balance equilibrium"); plt.grid(True); plt.show()
