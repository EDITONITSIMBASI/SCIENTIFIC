import numpy as np
from scipy.linalg import lu_factor, lu_solve

# Related case: repeated calculations for a building's three-zone water network.
A = np.array([[5., -1., 0.], [-1., 5., -1.], [0., -1., 4.]])
demand_sets = [np.array([18., 12., 10.]),
               np.array([20., 11., 9.]),
               np.array([16., 13., 12.])]
lu, piv = lu_factor(A)  # factor the fixed coefficient matrix once
for i, demand in enumerate(demand_sets, 1):
    flow = lu_solve((lu, piv), demand)
    print(f"Demand scenario {i}: flow values={flow}")
    print("Residual norm:", np.linalg.norm(demand - A @ flow))
