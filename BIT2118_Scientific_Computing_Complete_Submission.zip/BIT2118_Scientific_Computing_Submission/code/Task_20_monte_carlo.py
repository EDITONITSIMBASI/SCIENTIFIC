import numpy as np
import matplotlib.pyplot as plt

# Related case: estimate risk that estate daily water demand exceeds pump capacity.
rng = np.random.default_rng(42)
capacity = 950.0
mean_demand = 820.0
std_demand = 140.0  # changed uncertainty assumption
N = 100_000
demand = rng.normal(mean_demand, std_demand, N)
over = demand > capacity
prob = over.mean()
print(f"Estimated overload probability: {prob:.3%}")
print(f"Overload scenarios: {over.sum()} out of {N}")
running = np.cumsum(over) / np.arange(1, N+1)
indices = np.unique(np.logspace(1, np.log10(N), 200).astype(int))-1
plt.semilogx(indices+1, running[indices])
plt.xlabel("Number of simulations"); plt.ylabel("Estimated overload probability")
plt.title("Monte Carlo estimate of water-demand overload risk")
plt.grid(True); plt.show()
