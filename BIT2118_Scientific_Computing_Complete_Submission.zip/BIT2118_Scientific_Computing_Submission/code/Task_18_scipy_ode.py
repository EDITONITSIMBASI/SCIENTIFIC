import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Related case: model charging of a battery-like capacitor in a solar controller.
supply = 12.0
resistance = 2000.0
capacitance = 0.002
initial_voltage = 0.0
def circuit(t, voltage):
    return [(supply-voltage[0])/(resistance*capacitance)]
times = np.linspace(0, 20, 250)
sol = solve_ivp(circuit, (0, 20), [initial_voltage], t_eval=times, rtol=1e-9, atol=1e-11)
exact = supply*(1-np.exp(-sol.t/(resistance*capacitance)))
print("Solver success:", sol.success)
print(f"Voltage at 20 s: {sol.y[0,-1]:.4f} V")
print(f"Maximum error: {np.max(np.abs(sol.y[0]-exact)):.3e} V")
plt.plot(sol.t, sol.y[0], label="solve_ivp")
plt.plot(sol.t, exact, "--", label="Exact")
plt.xlabel("Time (s)"); plt.ylabel("Voltage (V)")
plt.title("Solar controller capacitor charging"); plt.legend(); plt.grid(True); plt.show()
