import numpy as np
from scipy.integrate import simpson

# Related case: estimate energy consumed by a water-pumping station.
time_h = np.array([0, 2, 4, 6, 8, 10, 12], dtype=float)
power_kw = np.array([1.1, 1.3, 1.8, 2.2, 2.0, 1.5, 1.0])
trap = np.trapezoid(power_kw, time_h)
simp = simpson(power_kw, x=time_h)
print(f"Trapezoidal energy estimate: {trap:.3f} kWh")
print(f"Simpson energy estimate: {simp:.3f} kWh")
print(f"Difference: {abs(simp-trap):.3f} kWh")
