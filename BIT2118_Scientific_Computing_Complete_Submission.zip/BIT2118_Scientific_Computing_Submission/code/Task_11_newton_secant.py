from scipy.optimize import root_scalar

# Related case: calculate the internal rate of return for a small solar installation.
cash_flows = [-12000, 3500, 4000, 4500, 4000]
def npv(rate):
    return sum(cf / (1 + rate)**t for t, cf in enumerate(cash_flows))
def derivative(rate):
    return sum(-t * cf / (1 + rate)**(t+1)
               for t, cf in enumerate(cash_flows) if t > 0)
newton = root_scalar(npv, fprime=derivative, x0=0.12, method="newton", xtol=1e-12)
secant = root_scalar(npv, x0=0.05, x1=0.25, method="secant", xtol=1e-12)
print(f"Newton-Raphson IRR: {newton.root:.6%}")
print(f"Secant IRR: {secant.root:.6%}")
print(f"NPV at calculated rate: {npv(newton.root):.8f}")
