import numpy as np
import timeit

# Related case: convert a large batch of electricity meter readings.
rng = np.random.default_rng(42)
energy_kwh = rng.uniform(0.1, 12.0, 500_000)

def loop_version():
    return [value * 1000 for value in energy_kwh]  # kWh to Wh

def vectorized_version():
    return energy_kwh * 1000

loop_time = timeit.timeit(loop_version, number=1)
vector_time = timeit.timeit(vectorized_version, number=10) / 10
watt_hours = vectorized_version()
print("First five readings (Wh):", watt_hours[:5])
print(f"Loop time: {loop_time:.6f} s")
print(f"Vectorized time: {vector_time:.6f} s")
print(f"Approximate speed-up: {loop_time / vector_time:.1f}x")
# Change: the original example used one million values; this case uses 500,000.
